<?php
namespace WDB\T3quotes\Domain\Model;

/***
 *
 * This file is part of the "Quotes database" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Kasper Skårhøj (2002) <kasper@typo3.com>, Curby Soft Multimedia
 *           David Bruchmann <david.bruchmann@gmail.com>, Webdevelopment Barlian
 *
 ***/

/**
 * TtContent
 */
class TtContent extends \TYPO3\CMS\Extbase\DomainObject\AbstractValueObject
{
    /**
     * t3quotesSelected
     *
     * @var bool
     */
    protected $t3quotesSelected = false;

    /**
     * Returns the t3quotesSelected
     *
     * @return bool $t3quotesSelected
     */
    public function getT3quotesSelected()
    {
        return $this->t3quotesSelected;
    }

    /**
     * Sets the t3quotesSelected
     *
     * @param bool $t3quotesSelected
     * @return void
     */
    public function setT3quotesSelected($t3quotesSelected)
    {
        $this->t3quotesSelected = $t3quotesSelected;
    }

    /**
     * Returns the boolean state of t3quotesSelected
     *
     * @return bool
     */
    public function isT3quotesSelected()
    {
        return $this->t3quotesSelected;
    }
}
